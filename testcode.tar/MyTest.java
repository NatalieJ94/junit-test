import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MyTest {

    @Test
    public void test() {
        assertEquals("You have installed JUnit correctly if this test returns this error message\n", true,false);
    }
}
